<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'subtitle' => null,
    'action' => null,
    'footer' => null,
    'noPadding' => false
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'subtitle' => null,
    'action' => null,
    'footer' => null,
    'noPadding' => false
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'bg-white rounded-xl border border-slate-200/80 shadow-2xs overflow-hidden'])); ?>>
    <?php if($title || $action): ?>
        <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between gap-4">
            <div>
                <?php if($title): ?>
                    <h3 class="text-sm font-semibold text-slate-900"><?php echo e($title); ?></h3>
                <?php endif; ?>
                <?php if($subtitle): ?>
                    <p class="text-xs text-slate-500 mt-0.5"><?php echo e($subtitle); ?></p>
                <?php endif; ?>
            </div>
            <?php if($action): ?>
                <div class="flex items-center gap-2">
                    <?php echo e($action); ?>

                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['p-5' => !$noPadding, 'p-0' => $noPadding]); ?>">
        <?php echo e($slot); ?>

    </div>

    <?php if($footer): ?>
        <div class="px-5 py-3.5 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\Projects\shuttercode-studio\resources\views/components/card.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'neutral',
    'dot' => false,
    'size' => 'sm'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'neutral',
    'dot' => false,
    'size' => 'sm'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $variants = [
        'success' => 'bg-emerald-50 text-emerald-700 border-emerald-200/80',
        'warning' => 'bg-amber-50 text-amber-700 border-amber-200/80',
        'danger' => 'bg-rose-50 text-rose-700 border-rose-200/80',
        'info' => 'bg-indigo-50 text-indigo-700 border-indigo-200/80',
        'sky' => 'bg-sky-50 text-sky-700 border-sky-200/80',
        'purple' => 'bg-purple-50 text-purple-700 border-purple-200/80',
        'neutral' => 'bg-slate-100 text-slate-700 border-slate-200',
    ];

    $dotColors = [
        'success' => 'bg-emerald-500',
        'warning' => 'bg-amber-500',
        'danger' => 'bg-rose-500',
        'info' => 'bg-indigo-500',
        'sky' => 'bg-sky-500',
        'purple' => 'bg-purple-500',
        'neutral' => 'bg-slate-400',
    ];

    $sizes = [
        'xs' => 'px-2 py-0.5 text-[11px]',
        'sm' => 'px-2.5 py-1 text-xs',
        'md' => 'px-3 py-1.5 text-xs font-semibold',
    ];

    $classes = 'inline-flex items-center gap-1.5 font-medium rounded-full border whitespace-nowrap shrink-0 ' . ($variants[$variant] ?? $variants['neutral']) . ' ' . ($sizes[$size] ?? $sizes['sm']);
    $dotClass = $dotColors[$variant] ?? $dotColors['neutral'];
?>

<span <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php if($dot): ?>
        <span class="w-1.5 h-1.5 rounded-full <?php echo e($dotClass); ?>"></span>
    <?php endif; ?>
    <?php echo e($slot); ?>

</span>
<?php /**PATH D:\Projects\shuttercode-studio\resources\views/components/badge.blade.php ENDPATH**/ ?>